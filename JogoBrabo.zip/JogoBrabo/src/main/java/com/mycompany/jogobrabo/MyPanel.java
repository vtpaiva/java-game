package com.mycompany.jogobrabo;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.MouseInfo;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.function.Function;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class MyPanel extends JPanel{
        public Hero hero;
        public ArrayList <Entidade> faseAtual;
        
        MyPanel(){            
            faseAtual = new ArrayList<>();
            hero = new Hero("caveira.png", 500/2, 300/2, this);
            faseAtual.add(hero);
            
            Movimento observer = new Movimento(this);
            this.addKeyListener(observer);
            this.addMouseListener(observer);
            this.addMouseMotionListener(observer);
            this.setBackground(Color.BLACK);
        }
        
        public int posicaoXValida() {
            return (int) ((Math.abs(this.getX() - (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10) <= Consts.MAX_WIDTH/2) ?
                         ((MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10) : 0);
        }
        
        public int posicaoYValida() {
            return (int) ((Math.abs(this.getY() - (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10) <= Consts.MAX_HEIGHT/2) ?
                         ((MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10) : 0);
        }
        
        public void addEntidade(Entidade p){
            faseAtual.add(p);
        }
        
        public void removeEntidade(int index){
            faseAtual.remove(index);
        }
        
        public void drawBackground(Graphics g, BufferedImage background){
            g.drawImage(background, 0, 0, null);
        }
        
        public static void drawChar(Graphics g, Entidade p){
            g.drawImage(p.sprite, p.getX(), p.getY(), null);
        }
        
        @Override
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            
            for(Entidade e: faseAtual){
                if(!e.update()) {
                    faseAtual.remove(e);
                }
                else {
                    drawChar(g, e);
                }
            }
        }
}
