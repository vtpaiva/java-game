package com.mycompany.jogobrabo;

public class InimigoSniper extends Inimigo{

    public InimigoSniper(String path, int linha, int coluna, int vida, int entityWidth, int entityHeight, MyPanel gamePanel, double angle) {
        super(path, linha, coluna, vida, entityWidth, entityHeight, gamePanel, angle);
        this.width = Consts.SNIPER_WIDTH;
        this.height = Consts.SNIPER_HEIGHT;
        this.rangeRadius = Consts.SNIPER_RANGE;
        this.visionRadius = Consts.SNIPER_VISION;
        
        this.updateRange();
        this.updateVision();
    }

    @Override
    public void ataque() {
        if(this.now - this.last >= 2000000000L) {
            gamePanel.addProjetil(new Projetil("caveira.png",
                                                this.getX(),
                                                this.getY(),
                                                (int) (gamePanel.hero.getX() - this.getX())/2,
                                                (int) (gamePanel.hero.getY() - this.getY())/2,
                                                gamePanel, false));
            this.last = System.nanoTime();
        }
    }
}
