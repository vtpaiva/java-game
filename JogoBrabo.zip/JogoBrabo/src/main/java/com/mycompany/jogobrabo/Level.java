package com.mycompany.jogobrabo;

import java.io.Serializable;
import java.util.ArrayList;

public class Level implements Serializable{
        public MyPanel panel;
        public int xSpawn, ySpawn;
        public int[][] levelMatrix;
    
        public ArrayList <Inimigo> inimigoAtual;
        public ArrayList <Obstaculo> obstaculoAtual;
        public ArrayList <Entidade> entidadeAtual;
        public ArrayList <Skip> skipAtual;
        
        public Level(MyPanel panel, int[][] levelMatrix, int xSpawn, int ySpawn) {
            this.panel = panel;
            this.levelMatrix = levelMatrix;
            this.xSpawn = xSpawn;
            this.ySpawn = ySpawn;
            
            inimigoAtual = new ArrayList<>();
            obstaculoAtual = new ArrayList<>();
            entidadeAtual = new ArrayList<>();
            skipAtual = new ArrayList<>();
        }
        
        public void apagaFase() {
            inimigoAtual.clear();
            obstaculoAtual.clear();
            entidadeAtual.clear();
            skipAtual.clear();
        }
        
        public void resetLevel(MyPanel gamePanel) {
            for(Entidade e: this.inimigoAtual) {
                e.gamePanel = gamePanel;
            }
            
            for(Entidade e: this.entidadeAtual) {
                e.gamePanel = gamePanel;
            }
            
            for(Entidade e: this.obstaculoAtual) {
                e.gamePanel = gamePanel;
            }
            
            for(Entidade e: this.skipAtual) {
                e.gamePanel = gamePanel;
            }
        }
        
        public void makeLevel() {
            for(int i = 0; i < Consts.LEVEL_SCALE * Consts.TILES_Y; i++) {
                for(int j = 0; j < Consts.LEVEL_SCALE * Consts.TILES_X; j++) {
                    entityInt(this.levelMatrix[i][j], j, i);
                }
            }
        }
        
        public void entityInt(int i, int linha, int coluna) {
            switch(i){
                case 1:
                    obstaculoAtual.add(new Obstaculo("paredeH.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_WIDTH, 
                                               Consts.TILE_HEIGHT, 
                                                 panel));
                    break;
                case 2:
                    obstaculoAtual.add(new Obstaculo("paredeV.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_WIDTH, 
                                               Consts.TILE_HEIGHT, 
                                                 panel));
                                                 break;
                case 3:
                    obstaculoAtual.add(new Obstaculo("cantoOS.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_WIDTH, 
                                               Consts.TILE_HEIGHT, 
                                                 panel));
                    break;
                case 4:
                    obstaculoAtual.add(new Obstaculo("cantoNO.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_HEIGHT, 
                                               Consts.TILE_WIDTH, 
                                                 panel));
                    break;
                case 5:
                    obstaculoAtual.add(new Obstaculo("cantoLN.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_HEIGHT, 
                                               Consts.TILE_WIDTH, 
                                                 panel));
                    break;
                case 6:
                    obstaculoAtual.add(new Obstaculo("cantoLS.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_HEIGHT, 
                                               Consts.TILE_WIDTH, 
                                                 panel));
                    break;
                case 7:
                    obstaculoAtual.add(new Obstaculo("beiraD.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_HEIGHT, 
                                               Consts.TILE_WIDTH, 
                                                 panel));
                    break;
                case 8:
                    obstaculoAtual.add(new Obstaculo("beiraE.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_HEIGHT, 
                                               Consts.TILE_WIDTH, 
                                                 panel));
                    break;
                case 9:
                    obstaculoAtual.add(new Obstaculo("beiraB.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_HEIGHT, 
                                               Consts.TILE_WIDTH, 
                                                 panel));
                    break;
                case 10:
                    obstaculoAtual.add(new Obstaculo("beiraC.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_HEIGHT, 
                                               Consts.TILE_WIDTH, 
                                                 panel));
                    break;
                case 11:
                    inimigoAtual.add(new InimigoBase("enemy.png", 
                                                    linha * Consts.TILE_HEIGHT, 
                                                    coluna * Consts.TILE_WIDTH, 
                                                    3, Consts.TILE_HEIGHT, Consts.TILE_WIDTH, panel, 0));
                    break;
                case 12:
                    inimigoAtual.add(new Boss("enemy.png", 
                                                    linha * Consts.TILE_HEIGHT, 
                                                    coluna * Consts.TILE_WIDTH, 
                                                    50, Consts.TILE_HEIGHT, Consts.TILE_WIDTH, panel, 0));
                    break;
                case 13:
                    inimigoAtual.add(new InimigoSniper("enemy.png", 
                                                    linha * Consts.TILE_HEIGHT, 
                                                    coluna * Consts.TILE_WIDTH, 
                                                    3, Consts.TILE_HEIGHT, Consts.TILE_WIDTH, panel, 0));
                    break;
                case 14:
                    obstaculoAtual.add(new Obstaculo("bush.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_HEIGHT, 
                                               Consts.TILE_WIDTH, 
                                                 panel));
                    break;
                case 15:
                    obstaculoAtual.add(new Obstaculo("tree.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                100, 
                                               100, 
                                                 panel));
                    break;
                case 16:
                    obstaculoAtual.add(new Obstaculo("tend.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                74, 
                                               50, 
                                                 panel));
                    break;
                case 17:
                    obstaculoAtual.add(new Obstaculo("car.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                112, 
                                               55, 
                                                 panel));
                    break;
                case 18:
                    obstaculoAtual.add(new Obstaculo("heli.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                205, 
                                               67, 
                                                 panel));
                    break;
                case 19:
                    obstaculoAtual.add(new Obstaculo("bush2.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                36, 
                                               24, 
                                                 panel));
                    break;
                case 20:
                    obstaculoAtual.add(new Obstaculo("roxa.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                69, 
                                               64, 
                                                 panel));
                    break;
                case 21:
                    obstaculoAtual.add(new Obstaculo("caveLN.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_WIDTH, 
                                               Consts.TILE_HEIGHT, 
                                                 panel));
                    break;
                case 22:
                    obstaculoAtual.add(new Obstaculo("caveLS.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_WIDTH, 
                                               Consts.TILE_HEIGHT, 
                                                 panel));
                    break;
                case 23:
                    obstaculoAtual.add(new Obstaculo("caveNO.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_WIDTH, 
                                               Consts.TILE_HEIGHT,  
                                                 panel));
                    break;
                case 24:
                    obstaculoAtual.add(new Obstaculo("caveOS.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_WIDTH, 
                                               Consts.TILE_HEIGHT, 
                                                 panel));
                    break;
                case 25:
                    entidadeAtual.add(new Corpo("fire.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                15, 
                                               15, 
                                                 panel));
                    break;
                case 26:
                    entidadeAtual.add(new Corpo("wood.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                15, 
                                               15, 
                                                 panel));
                    break;
                case 27:
                    entidadeAtual.add(new Corpo("blood.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                15, 
                                               15, 
                                                 panel));
                    break;
                case 28:
                    obstaculoAtual.add(new Obstaculo("caveH.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_WIDTH, 
                                               Consts.TILE_HEIGHT, 
                                                 panel));
                    break;
                case 29:
                    obstaculoAtual.add(new Obstaculo("caveV.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_WIDTH, 
                                               Consts.TILE_HEIGHT, 
                                                 panel));
                    break;
                case 30:
                    obstaculoAtual.add(new Obstaculo("caveBeiraD.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_WIDTH, 
                                               Consts.TILE_HEIGHT, 
                                                 panel));
                    break;
                case 31:
                    obstaculoAtual.add(new Obstaculo("caveBeiraE.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_WIDTH, 
                                               Consts.TILE_HEIGHT, 
                                                 panel));
                    break;
                case 32:
                    skipAtual.add(new Skip("caveira.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                Consts.TILE_WIDTH, 
                                               Consts.TILE_HEIGHT, 
                                                 panel));
                    break;    
                case 33:
                    obstaculoAtual.add(new Obstaculo("log.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                36, 
                                               102, 
                                                 panel));
                    break;   
                case 34:
                    obstaculoAtual.add(new Obstaculo("box.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                49, 
                                               22, 
                                                 panel));
                    break;   
                case 35:
                    obstaculoAtual.add(new Obstaculo("box2.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                22, 
                                               49, 
                                                 panel));
                    break; 
                case 36:
                    inimigoAtual.add(new InimigoBase("enemy.png", 
                                                    linha * Consts.TILE_HEIGHT, 
                                                    coluna * Consts.TILE_WIDTH, 
                                                    3, Consts.TILE_HEIGHT, Consts.TILE_WIDTH, panel, 0));
                    break;
                default:
            }
        }
}
