package com.mycompany.jogobrabo;

import java.awt.Graphics2D;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;

public class Movimento implements KeyListener, MouseListener, MouseMotionListener{
    public MyPanel panel;

    Movimento(MyPanel panel){
        this.panel = panel;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch(e.getKeyCode()){
            case KeyEvent.VK_W -> panel.setLocation(panel.getX() - panel.posicaoXValida(), panel.getY() - panel.posicaoYValida());
            case KeyEvent.VK_SPACE -> panel.addEntidade(new Projetil(
                        "caveira.png",
                        panel.hero.getX(),
                        panel.hero.getY(),
                        (int) (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2)/100,
                        (int) (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2)/100));
        }
        panel.repaint();
    }
    
    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        panel.hero.rotate(MouseInfo.getPointerInfo().getLocation());
    }
}
