package Controle;

//  Felipe Aparecido da Silva - 11954502.
//  Vítor Augusto Paiva de Brito - 13732303.

public class Jogo {
    public static void main(String[] args) {
        (new MyGame()).run();
    }
}
