package com.mycompany.jogobrabo;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.MouseInfo;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

public abstract class Inimigo extends Personagem{
    public boolean hunt;
    public Ellipse2D range, vision;
    public int width, height, rangeRadius, visionRadius;
    
    public Inimigo(String path, int linha, int coluna, int vida, int entityWidth, int entityHeight, MyPanel gamePanel, double angle) {
        super(path, linha, coluna, vida, entityWidth, entityHeight, gamePanel, angle);
        this.updateRange();
        this.updateVision();
    }
    
    public final void updateRange() {
        this.range = new Ellipse2D.Double(this.getX() - rangeRadius/2 + width/2, this.getY() - rangeRadius/2 + height/2, rangeRadius, rangeRadius);
    }
    
    public final void updateVision() {
        this.vision = new Ellipse2D.Double(this.getX() - visionRadius/2 + width/2, this.getY() - visionRadius/2 + height/2, visionRadius, visionRadius);
    }
    
    public void rotate() {
        BufferedImage rotatedImage = new BufferedImage(sprite.getWidth(), sprite.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = rotatedImage.createGraphics();

        g2.rotate(Math.atan2((this.gamePanel.hero.getY() - Consts.MAX_HEIGHT/2), this.gamePanel.hero.getX() - Consts.MAX_WIDTH/2) + angle, rotatedImage.getWidth() / 2, rotatedImage.getHeight() / 2);
        
        
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2.drawImage(sprite, null, 0, 0);

        g2.dispose();
        
        rotateSprite = rotatedImage;
    }
    
    public int posicaoXValida() {
            if((Math.abs(this.getX() + (gamePanel.hero.getX() - this.getX())/40) > Consts.MAX_WIDTH)) {
                return this.getX();
            }
            
            for(Obstaculo o: this.gamePanel.fase.obstaculoAtual) {
                if(o.hitbox.intersects(new Rectangle2D.Double(this.getX() + (gamePanel.hero.getX() - this.getX())/40, this.getY(), this.hitbox.getWidth(), this.hitbox.getHeight()))) {
                    return this.getX();
                }
            }
            
            return (int) (this.getX() + (gamePanel.hero.getX() - this.getX())/40);
    }
    
    public int posicaoYValida() {
            if((Math.abs(this.getY() + (gamePanel.hero.getY() - this.getY())/40) > Consts.MAX_HEIGHT)) {
                return this.getY();
            }
            
            for(Obstaculo o: this.gamePanel.fase.obstaculoAtual) {
                if(o.hitbox.intersects(new Rectangle2D.Double(this.getX(), this.getY() + (gamePanel.hero.getY() - this.getY())/40, this.hitbox.getWidth(), this.hitbox.getHeight()))) {
                    return this.getY();
                }
            }
            
            return (int) (this.getY() + (gamePanel.hero.getY() - this.getY())/40);
    }
    
    public boolean posicaoValida() {
        return !(this.range.intersects(this.gamePanel.hero.hitbox));
    }
    
    protected void paintComponent(Graphics g) {
        g.drawImage(this.sprite, this.getX(), this.getY(), null);
    }
    
    public abstract void ataque();
    
    @Override
    public boolean update() {
        if(hunt) {
            if(posicaoValida()) {
                this.setLocation(posicaoXValida(), posicaoYValida());
            }
            if(this.range.intersects(this.gamePanel.hero.hitbox)) {
                this.ataque();
            }
            this.updateHitbox((int) this.hitbox.getWidth(),(int) this.hitbox.getHeight());
            this.updateRange();
            this.updateVision();
            this.rotate();
        }
        else {
            if(this.vision.intersects(this.gamePanel.hero.hitbox)) {
                for(Obstaculo o: this.gamePanel.fase.obstaculoAtual) {
                    if((new Line2D.Double(this.getX(), this.getY(), this.gamePanel.hero.getX(), this.gamePanel.hero.getY())).intersects(o.hitbox)) {
                        return vida > 0;
                    }
                }
                
                hunt = true;
            }
        }
        
        return vida > 0;
    }
}
