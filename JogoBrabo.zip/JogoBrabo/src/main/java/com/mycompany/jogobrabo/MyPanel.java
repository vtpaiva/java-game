package com.mycompany.jogobrabo;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.MouseInfo;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.JPanel;

public class MyPanel extends JPanel{
        public Hero hero;
        
        public Level fase;
        
        MyPanel(){            
            hero = new Hero("main.png", 500/2, 300/2, 1, Consts.TILE_WIDTH, Consts.TILE_HEIGHT, this, Math.PI/2);
            fase = new Level(this);
            fase.makeLevel(Fases.Fase1);
            
            Movimento observer = new Movimento(this);
            this.addKeyListener(observer);
            this.addMouseListener(observer);
            this.addMouseMotionListener(observer);
            this.setBackground(Color.BLACK);
        }
        
        public int posicaoXValidaForward() {
            if((Math.abs(this.getX() - (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10) > Consts.MAX_WIDTH/2)) {
                return this.getX();
            }
            
            for(Obstaculo o: fase.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX()- (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10, o.getY(), o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getX();
                }
            }
            
            return (int) (this.getX() - (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10);
        }
        
        public int posicaoYValidaForward() {
            if((Math.abs(this.getY() - (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10) > Consts.MAX_HEIGHT/2)) {
                return this.getY();
            }
            
            for(Obstaculo o: fase.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX(), o.getY() - (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10, o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getY();
                }
            }
            
            return (int) (this.getY() - (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10);
        }
        
        public int posicaoXValidaBackward() {
            if((Math.abs(this.getX() + (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10) > Consts.MAX_WIDTH/2)) {
                return this.getX();
            }
            
            for(Obstaculo o: fase.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX() + (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10, o.getY(), o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getX();
                }
            }
            
            return (int) (this.getX() + (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10);
        }
        
        public int posicaoYValidaBackward() {
            if((Math.abs(this.getY() + (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10) > Consts.MAX_HEIGHT/2)) {
                return this.getY();
            }
            
            for(Obstaculo o: fase.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX(), o.getY() + (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10, o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getY();
                }
            }
            
            return (int) (this.getY() + (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10);
        }
        
        public int posicaoXValidaRight() {
            if((Math.abs(this.getX() - (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10) > Consts.MAX_HEIGHT/2)) {
                return this.getX();
            }
            
            for(Obstaculo o: fase.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX() - (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10, o.getY(), o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getX();
                }
            }
            
            return (int) (this.getX() - (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10);
        }
        
        public int posicaoYValidaRight() {
            if((Math.abs(this.getY() + (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10) > Consts.MAX_WIDTH/2)) {
                return this.getY();
            }
            
            for(Obstaculo o: fase.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX(), o.getY() + (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10, o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getY();
                }
            }
            
            return (int) (this.getY() + (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10);
        }
        
        public int posicaoXValidaLeft() {
            if((Math.abs(this.getX() + (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10) > Consts.MAX_HEIGHT/2)) {
                return this.getX();
            }
            
            for(Obstaculo o: fase.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX() + (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10, o.getY(), o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getX();
                }
            }
            
            return (int) (this.getX() + (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10);
        }
        
        public int posicaoYValidaLeft() {
            if((Math.abs(this.getY() - (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10) > Consts.MAX_WIDTH/2)) {
                return this.getY();
            }
            
            for(Obstaculo o: fase.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX(), o.getY() - (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10, o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getY();
                }
            }
            
            return (int) (this.getY() - (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10);
        }
        
        public void moveForward() {
            this.setLocation(posicaoXValidaForward(), posicaoYValidaForward());
        }
        
        public void moveBackward() {
            this.setLocation(posicaoXValidaBackward(), posicaoYValidaBackward());
        }
        
        public void moveRight() {
            this.setLocation(posicaoXValidaRight(), posicaoYValidaRight());
        }
        
        public void moveLeft() {
            this.setLocation(posicaoXValidaLeft(), posicaoYValidaLeft());
        }
        
        public void addProjetil(Projetil p){
            fase.projetilAtual.add(p);
        }
        
        public void addObstavulo(Obstaculo o){
            fase.obstaculoAtual.add(o);
        }
        
        public void addInimigo(Inimigo i) {
            fase.inimigoAtual.add(i);
        }
        
        public void updateHero(Graphics g) {
            this.hero.update();
            this.hero.paintComponent(g);
            this.hero.now = System.nanoTime();
        }
        
        public void drawBackground(Graphics g, BufferedImage background){
            g.drawImage(background, 0, 0, null);
        }
        
        public static void drawChar(Graphics g, Entidade p){
            g.drawImage(p.sprite, p.getX(), p.getY(), null);
        }
        
        @Override
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            
            fase.inimigoAtual.removeIf(i -> !i.update());
            fase.projetilAtual.removeIf(p -> !p.update());
            
            for(Obstaculo o: fase.obstaculoAtual) {
                o.paintComponent(g);
            }
            
            for(Inimigo i: fase.inimigoAtual) {
                i.now = System.nanoTime();
                i.paintComponent(g);
            }
            
            for(Entidade e: fase.projetilAtual) {
                e.paintComponent(g);
            }
            
            updateHero(g);
        }
}
