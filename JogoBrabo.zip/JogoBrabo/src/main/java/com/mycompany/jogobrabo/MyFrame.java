package com.mycompany.jogobrabo;
import static com.sun.java.accessibility.util.AWTEventMonitor.addKeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;

public class MyFrame extends JFrame{
    public JFrame frame;
    
    MyFrame(MyPanel gamePanel) {
        frame = new JFrame();
        frame.add(gamePanel);
        frame.setSize(gamePanel.getWidth(), gamePanel.getHeight());
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH); 
        frame.setVisible(true);
    }
}
