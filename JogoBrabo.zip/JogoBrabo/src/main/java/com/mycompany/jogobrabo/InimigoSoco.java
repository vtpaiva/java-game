package com.mycompany.jogobrabo;

import java.awt.geom.Ellipse2D;
import java.io.Serializable;

public class InimigoSoco extends Inimigo implements Serializable{
    public InimigoSoco(String path, int linha, int coluna, int vida, int entityHeight, int entityWidth, MyPanel gamePanel, double angle) {
super(path, linha, coluna, vida, entityWidth, entityHeight, gamePanel, angle);
        this.width = Consts.PUNCH_WIDTH;
        this.height = Consts.PUNCH_HEIGHT;
        this.rangeRadius = Consts.PUNCH_RANGE;
        this.visionRadius = Consts.PUNCH_VISION;
        
        this.updateRange();
        this.updateVision();
    }

    @Override
    public void ataque() {
        if(this.now - this.last >= 100000000) {
            punchHero();
            this.last = System.nanoTime();
        }
    }
    
    public void punchHero() {
            this.gamePanel.hero.vida--;
    }
}
