package com.mycompany.jogobrabo;

import java.awt.Graphics;
import java.awt.RenderingHints;
import java.util.ArrayList;
import javax.swing.JPanel;

public class MyPanel extends JPanel{
        public Hero hero;
        public ArrayList <Entidade> faseAtual;
        
        MyPanel(){
            faseAtual = new ArrayList<Entidade>();
            hero = new Hero("caveira.png", 0, 0);
            faseAtual.add(hero);
            this.addKeyListener(new Movimento(this));
            this.addMouseListener(new Movimento(this));
            this.addMouseMotionListener(new Movimento(this));
        }
        
        public void addEntidade(Entidade p){
            faseAtual.add(p);
        }
        
        public void removeEntidade(int index){
            faseAtual.remove(index);
        }
        
        public void fixaIndex(Entidade e){
            for(int i = faseAtual.indexOf(e); i < faseAtual.size() - 1 && i > -1; faseAtual.get(i++)) {}
        }
        
        public static void drawChar(Graphics g, Entidade p){
            g.drawImage(p.sprite, (int) p.getX(), (int) p.getY(), null);
        }
        
        @Override
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            
            for(Entidade e: faseAtual){
                if(!e.update()) {
                    faseAtual.remove(e);
                }
                else {
                    drawChar(g, e);
                }
            }
        }
}
