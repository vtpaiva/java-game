package Controle;

public class JogoBrabo {
    public static void main(String[] args) {
        (new MyGame()).run();
    }
}
