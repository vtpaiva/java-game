package com.mycompany.jogobrabo;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public abstract class Personagem extends Entidade{
    BufferedImage rotateSprite;
    
    public int vida;
    public double angle, last, now;

    public Personagem(String path, int linha, int coluna, int vida, int entityWidth, int entityHeight, MyPanel gamePanel, double angle) {
        super(path, linha, coluna, entityWidth, entityHeight, gamePanel);
        this.angle = angle;
        this.rotateSprite = sprite;
        this.vida = vida;
        this.last = this.now = System.nanoTime();
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        g.drawImage(this.rotateSprite, this.getX(), this.getY(), null);
    }
}
