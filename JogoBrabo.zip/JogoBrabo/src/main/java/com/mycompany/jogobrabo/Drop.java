package com.mycompany.jogobrabo;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

public abstract class Drop extends Entidade {
    public double last;
    public boolean coletavel;

    public Drop(String path, int linha, int coluna, int entityWidth, int entityHeight, MyPanel gamePanel) {
        super(path, linha, coluna, entityWidth, entityHeight, gamePanel);
        this.last = System.nanoTime();
    }
    
    public final void rotate() {
        BufferedImage rotatedImage = new BufferedImage(sprite.getWidth(), sprite.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = rotatedImage.createGraphics();

        g2.rotate(Math.atan2((this.getY() - this.gamePanel.hero.getY()), this.getX() - this.gamePanel.hero.getX()), rotatedImage.getWidth() / 2, rotatedImage.getHeight() / 2);
        
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2.drawImage(sprite, null, 0, 0);

        g2.dispose();
        
        this.sprite = rotatedImage;
    }
    
    public abstract void efeitoColetavel();
    
    @Override
    public boolean update() {
        if(this.coletavel && this.hitbox.intersects(this.gamePanel.hero.hitbox)) {
            this.efeitoColetavel();
            return false;
        }
        return true;
    }
}
