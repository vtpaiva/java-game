package com.mycompany.jogobrabo;

public class LevelConsts {
    public static int defaultB = 1;
}
