package com.mycompany.jogobrabo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.MouseInfo;
import java.awt.geom.Rectangle2D;
import java.io.Serializable;
import java.util.ArrayList;
import javax.swing.JPanel;

public class MyPanel extends JPanel implements Serializable{
        public Hero hero;
        public Level faseAtual;
        public ArrayList <Level> fases;
        
        public SaveLoad saveLoad;
        public Movimento observer;
        public int gameState;
        
        MyPanel() {
            fases = new ArrayList<>();
            this.makeLevels();
            this.faseAtual = fases.get(0);
            hero = new Hero("main.png", this.faseAtual.xSpawn, this.faseAtual.ySpawn, 50, Consts.TILE_WIDTH, Consts.TILE_HEIGHT, this, Math.PI / 2, 200);
            this.faseAtual.makeLevel();
            saveLoad = new SaveLoad(this);
            this.setPreferredSize(new Dimension(Consts.MAX_RES_WIDTH * 2, Consts.MAX_RES_HEIGHT * 2));
            this.gameState = 0;
            
            this.observer = new Movimento(this);
            this.addKeyListener(observer);
            this.addMouseListener(observer);
            this.addMouseMotionListener(observer);
            this.setBackground(new Color(0, 102, 0));
        }
        
        public final void setGame() {
            this.faseAtual.apagaFase();
            
            this.faseAtual = fases.get(0);
            hero = new Hero("main.png", this.faseAtual.xSpawn, this.faseAtual.ySpawn, 50, Consts.TILE_WIDTH, Consts.TILE_HEIGHT, this, Math.PI / 2, 200);
            this.faseAtual.makeLevel();
            this.gameState = 0;
            
            this.removeKeyListener(observer);
            this.removeMouseListener(observer);
            this.removeMouseMotionListener(observer);
            
            this.observer = new Movimento(this);
            this.addKeyListener(observer);
            this.addMouseListener(observer);
            this.addMouseMotionListener(observer);
            this.setBackground(new Color(0, 102, 0));
        }
        
        public final void makeLevels() {
            for(int[][] i: Fases.Fases) {
                fases.add(new Level(this, i, 1, 1));
            }
        }
        
        public int posicaoXValidaForward() {
            if((Math.abs(this.getX() - (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10) > Consts.MAX_WIDTH * Consts.LEVEL_SCALE)) {
                return this.getX();
            }
            
            for(Obstaculo o: faseAtual.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX()- (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10, o.getY(), o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getX();
                }
            }
            
            return (int) (this.getX() - (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10);
        }
        
        public int posicaoYValidaForward() {
            if((Math.abs(this.getY() - (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10) > Consts.MAX_HEIGHT * Consts.LEVEL_SCALE)) {
                return this.getY();
            }
            
            for(Obstaculo o: faseAtual.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX(), o.getY() - (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10, o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getY();
                }
            }
            
            return (int) (this.getY() - (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10);
        }
        
        public int posicaoXValidaBackward() {
            if((Math.abs(this.getX() + (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10) > Consts.MAX_WIDTH * Consts.LEVEL_SCALE)) {
                return this.getX();
            }
            
            for(Obstaculo o: faseAtual.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX() + (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10, o.getY(), o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getX();
                }
            }
            
            return (int) (this.getX() + (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10);
        }
        
        public int posicaoYValidaBackward() {
            if((Math.abs(this.getY() + (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10) > Consts.MAX_HEIGHT * Consts.LEVEL_SCALE)) {
                return this.getY();
            }
            
            for(Obstaculo o: faseAtual.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX(), o.getY() + (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10, o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getY();
                }
            }
            
            return (int) (this.getY() + (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10);
        }
        
        public int posicaoXValidaRight() {
            if((Math.abs(this.getX() - (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10) > Consts.MAX_WIDTH * Consts.LEVEL_SCALE)) {
                return this.getX();
            }
            
            for(Obstaculo o: faseAtual.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX() - (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10, o.getY(), o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getX();
                }
            }
            
            return (int) (this.getX() - (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10);
        }
        
        public int posicaoYValidaRight() {
            if((Math.abs(this.getY() + (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10) > Consts.MAX_HEIGHT * Consts.LEVEL_SCALE)) {
                return this.getY();
            }
            
            for(Obstaculo o: faseAtual.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX(), o.getY() + (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10, o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getY();
                }
            }
            
            return (int) (this.getY() + (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10);
        }
        
        public int posicaoXValidaLeft() {
            if((Math.abs(this.getX() + (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10) > Consts.MAX_WIDTH * Consts.LEVEL_SCALE)) {
                return this.getX();
            }
            
            for(Obstaculo o: faseAtual.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX() + (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10, o.getY(), o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getX();
                }
            }
            
            return (int) (this.getX() + (MouseInfo.getPointerInfo().getLocation().getY() - Consts.MAX_HEIGHT/2) / 10);
        }
        
        public int posicaoYValidaLeft() {
            if((Math.abs(this.getY() - (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10) > Consts.MAX_HEIGHT * Consts.LEVEL_SCALE)) {
                return this.getY();
            }
            
            for(Obstaculo o: faseAtual.obstaculoAtual) {
                if(hero.hitbox.intersects(new Rectangle2D.Double(o.getX(), o.getY() - (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10, o.hitbox.getWidth(), o.hitbox.getHeight()))) {
                    return this.getY();
                }
            }
            
            return (int) (this.getY() - (MouseInfo.getPointerInfo().getLocation().getX() - Consts.MAX_WIDTH/2) / 10);
        }
        
        public void moveForward() {
            this.setLocation(posicaoXValidaForward(), posicaoYValidaForward());
        }
        
        public void moveBackward() {
            this.setLocation(posicaoXValidaBackward(), posicaoYValidaBackward());
        }
        
        public void moveRight() {
            this.setLocation(posicaoXValidaRight(), posicaoYValidaRight());
        }
        
        public void moveLeft() {
            this.setLocation(posicaoXValidaLeft(), posicaoYValidaLeft());
        }
        
        public void addEntidade(Entidade e){
            faseAtual.entidadeAtual.add(e);
        }
        
        public void addObstaculo(Obstaculo o){
            faseAtual.obstaculoAtual.add(o);
        }
        
        public void addInimigo(Inimigo i) {
            faseAtual.inimigoAtual.add(i);
        }
        
        public void updateHero(Graphics g) {
            if(!this.hero.update()) {
                this.gameOverScreen(g);
            }
            this.hero.paintComponent(g);
            this.hero.now = System.nanoTime();
        }
        
        public void proximaFase() {
            if(this.fases.indexOf(this.faseAtual) + 1 < this.fases.size()) {
                this.faseAtual.inimigoAtual.clear();
                this.faseAtual.obstaculoAtual.clear();
                this.faseAtual.entidadeAtual.clear();
                this.faseAtual.skipAtual.clear();

                this.faseAtual = this.fases.get(this.fases.indexOf(this.faseAtual) + 1);

                this.faseAtual.makeLevel();
                this.hero.setLocation(this.faseAtual.xSpawn, this.faseAtual.ySpawn);
            }
            else {
                youWinScreen();
            }
        }
        
        public void youWinScreen() {
            this.gameState = 1;
            this.observer.listenActive = false;
            repaint();
        }
        
        public void gameOverScreen(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            
            this.gameState = 2;
            this.observer.listenActive = false;
            g2.setColor(new Color(0, 0, 0, 50));
            g2.fillRect(0, 0, Consts.MAX_WIDTH * Consts.LEVEL_SCALE, Consts.MAX_HEIGHT * Consts.LEVEL_SCALE);
            g2.setColor(Color.white);
            g2.setFont(g2.getFont().deriveFont(Font.BOLD, 50f));
            g2.drawString("Game Over", this.hero.getX() - 125, this.hero.getY());
        }
        
        private static final int NUMERO_DE_LINHAS = 10;
        private static final int DIAMETRO_PONTO = 5;
    
        public void drawGrass(Graphics g) {
            
            for(int i = -20; i < 20; i++) {
                g.setColor(new Color(i + 20, 204 + i, 0 + i * 5 + 100));
                for (int x = 0; x < getWidth(); x += 50) {
                    int y = (int) (i / 10 * x);
                    g.fillOval(i*i * 10 + x - DIAMETRO_PONTO / 2, i*i + y - DIAMETRO_PONTO / 2, DIAMETRO_PONTO, DIAMETRO_PONTO);
                }
            }
        }
        
        @Override
        public void paintComponent(Graphics g){
                super.paintComponent(g);
                
                this.drawGrass(g);
                
                Graphics2D g2 = (Graphics2D) g;
                
                for(Entidade e: faseAtual.entidadeAtual) {
                    e.paintComponent(g);
                }

                for(Obstaculo o: faseAtual.obstaculoAtual) {
                    o.paintComponent(g);
                }

                for(Skip s: faseAtual.skipAtual) {
                    s.paintComponent(g);
                }

                for(Inimigo i: faseAtual.inimigoAtual) {
                    i.now = System.nanoTime();
                    i.paintComponent(g);
                }
                
                if(this.gameState == 0) {
                    faseAtual.inimigoAtual.removeIf(i -> !i.update());
                    faseAtual.entidadeAtual.removeIf(p -> !p.update());
                    updateHero(g);
               }
                else {
                    switch(this.gameState) {
                        case 1:
                            g2.setColor(new Color(0, 0, 0, 50));
                            g2.fillRect(0, 0, Consts.MAX_WIDTH * Consts.LEVEL_SCALE, Consts.MAX_HEIGHT * Consts.LEVEL_SCALE);
                            g2.setColor(Color.yellow);
                            g2.setFont(g2.getFont().deriveFont(Font.BOLD, 50f));
                            g2.drawString("You win", this.hero.getX() - 125, this.hero.getY());
                            g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));
                            g2.setColor(Color.white);
                            g2.drawString("Felipe Aparecido da Silva", this.hero.getX() - 210, this.hero.getY() + 50);
                            g2.drawString("Vitor Augusto Paiva de Brito", this.hero.getX() - 230, this.hero.getY() + 100);
                            break;
                        case 2:
                            this.gameOverScreen(g);
                            break;
                        default:
                    }
                }
            }
        }
