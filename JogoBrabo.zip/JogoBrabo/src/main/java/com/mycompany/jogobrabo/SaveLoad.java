package com.mycompany.jogobrabo;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SaveLoad implements Serializable {
    public MyPanel gamePanel;

    public SaveLoad(MyPanel gamePanel) {
        this.gamePanel = gamePanel;
    }

    public void save() throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File("save.dat")))) {
            DataStorage ds = new DataStorage(this.gamePanel);
            
            oos.writeObject(ds);
        } catch (IOException e) {
            e.getMessage();
        }
    }

    public void load() throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File("save.dat")))) {
            DataStorage ds = (DataStorage) ois.readObject();
            
            gamePanel.setLocation(ds.gamePanel.getX(), ds.gamePanel.getY());
            gamePanel.faseAtual = ds.gamePanel.faseAtual;
            
            for(Entidade e: gamePanel.faseAtual.entidadeAtual) {
                if(e instanceof Drop drop) {
                    drop.last = System.nanoTime();
                }
            }
            
            for(Inimigo i: gamePanel.faseAtual.inimigoAtual) {
                i.rotateSprite = i.sprite;
            }
            
            gamePanel.hero = ds.gamePanel.hero;
            gamePanel.hero.rotateSprite = gamePanel.hero.sprite;
            gamePanel.hero.gamePanel = gamePanel;
        } catch (IOException | ClassNotFoundException e) {
            e.getMessage();
        }
    }
}
