package com.mycompany.jogobrabo;

import java.awt.Graphics;

public class Projetil extends Entidade{
    public int xDeslocamento, yDeslocamento;
    
    public Projetil(String path, int linha, int coluna, int xDeslocamento, int yDeslocamento) {
        super(path, linha, coluna);
        
        if(xDeslocamento == 0 && yDeslocamento == 0){
            this.xDeslocamento = this.yDeslocamento = -1;
        }
        else {
            this.xDeslocamento = xDeslocamento;
            this.yDeslocamento = yDeslocamento;
        }
    }
    
    @Override
    public boolean update(){
        if(!posicaoValida(this.getX() + xDeslocamento, this.getY() + yDeslocamento)) {return false;}
        
        this.setLocation((int) (this.getX() + xDeslocamento), (int) (this.getY() + yDeslocamento));
        return true;
    }
}
