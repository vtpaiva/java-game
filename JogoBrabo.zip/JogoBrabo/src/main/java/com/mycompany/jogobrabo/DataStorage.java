package com.mycompany.jogobrabo;

import java.io.Serializable;
import java.util.ArrayList;

public class DataStorage implements Serializable {
    public MyPanel gamePanel;
    
    public DataStorage(MyPanel gamePanel) {
        this.gamePanel = gamePanel;
    }
}
