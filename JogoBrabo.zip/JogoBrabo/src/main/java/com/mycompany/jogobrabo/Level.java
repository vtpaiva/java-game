package com.mycompany.jogobrabo;

import java.util.ArrayList;

public class Level {
        public MyPanel panel;
    
        public ArrayList <Inimigo> inimigoAtual;
        public ArrayList <Obstaculo> obstaculoAtual;
        public ArrayList <Projetil> projetilAtual;

        
        public Level(MyPanel panel) {
            this.panel = panel;
            
            inimigoAtual = new ArrayList<>();
            obstaculoAtual = new ArrayList<>();
            projetilAtual = new ArrayList<>();
        }
        
        public void makeLevel(int[][] data) {
            for(int i = 0; i < Consts.TILES_Y - 1; i++) {
                for(int j = 0; j < Consts.TILES_X - 1; j++) {
                    entityInt(data[i][j], j, i);
                }
            }
        }
        
        public void entityInt(int i, int linha, int coluna) {
            switch(i){
                case 1:
                    inimigoAtual.add(new InimigoBase("enemy.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH, 
                                                     1, 
                                                         Consts.TILE_WIDTH, 
                                                Consts.TILE_HEIGHT, 
                                                 panel, 
                                                    0));
                                                    break;
                case 2:
                    obstaculoAtual.add(new Obstaculo("caveira.png", 
                                                         linha * Consts.TILE_HEIGHT, 
                                                         coluna * Consts.TILE_WIDTH,
                                                         Consts.TILE_WIDTH, 
                                                Consts.TILE_HEIGHT, 
                                                 panel));
                                                 break;
                default:
                    return;
            }
        }
}
