package com.mycompany.jogobrabo;

public class Vida extends Drop {

    public Vida(String path, int linha, int coluna, int entityWidth, int entityHeight, MyPanel gamePanel) {
        super(path, linha, coluna, entityWidth, entityHeight, gamePanel);
        this.coletavel = true;
    }

    @Override
    public void efeitoColetavel() {
        this.gamePanel.hero.vida += (this.gamePanel.hero.vida > this.gamePanel.hero.vidaMax - 20) ?
                                     this.gamePanel.hero.vidaMax - this.gamePanel.hero.vida : 20;
    }
    
    @Override
    public boolean update() {
        if(this.coletavel && this.hitbox.intersects(this.gamePanel.hero.hitbox)) {
            this.efeitoColetavel();
            return false;
        }
        
        if(System.nanoTime() - this.last > 10000000000L) {
            return false;
        }
        
        return true;
    }
}
