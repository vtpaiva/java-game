package com.mycompany.jogobrabo;

import java.awt.geom.Ellipse2D;

public final class InimigoBase extends Inimigo{
    
    public InimigoBase(String path, int linha, int coluna, int vida, MyPanel gamePanel, double angle) {
        super(path, linha, coluna, vida, gamePanel, angle);
        this.updateRange();
    }
}
