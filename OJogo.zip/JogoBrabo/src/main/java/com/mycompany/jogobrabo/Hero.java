package com.mycompany.jogobrabo;

public class Hero extends Entidade {

    public Hero(String path, int linha, int coluna) {
        super(path, linha, coluna);
    }

    @Override
    public boolean update() {
        return true;
    }
}
