package com.mycompany.jogobrabo;

public class Municao extends Drop {
    public Municao(String path, int linha, int coluna, int entityWidth, int entityHeight, MyPanel gamePanel) {
        super(path, linha, coluna, entityWidth, entityHeight, gamePanel);
        this.coletavel = true;
    }

    @Override
    public void efeitoColetavel() {
        this.gamePanel.hero.ammo += (this.gamePanel.hero.ammo > this.gamePanel.hero.maxAmmo - 100) ?
                                     this.gamePanel.hero.maxAmmo - this.gamePanel.hero.ammo : 100;
    }
    
        @Override
    public boolean update() {
        if(this.coletavel && this.hitbox.intersects(this.gamePanel.hero.hitbox)) {
            this.efeitoColetavel();
            return false;
        }
        
        if(System.nanoTime() - this.last > 10000000000L) {
            return false;
        }
        
        return true;
    }
}
