package com.mycompany.jogobrabo;
import static com.sun.java.accessibility.util.AWTEventMonitor.addKeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;

public class MyFrame {
    public JFrame frame;
    
    MyFrame(MyPanel gamePanel) {
        frame = new JFrame();
        frame.setLocation(0, 0);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH); 
        frame.add(gamePanel);
        frame.setResizable(true);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
